#!/bin/bash
# filename: merge_gene_counts_efficient.sh

OUTPUT_DIR="./count_results"
FINAL_COUNTS_FILE="all_samples_gene_counts.csv"

echo "Starting efficient merge of gene counts..."

# Check if count files exist
if [ ! -f "$OUTPUT_DIR/Tco-230_gene_counts.txt" ]; then
    echo "Error: Gene count files not found."
    exit 1
fi

# Get sample list
ls $OUTPUT_DIR/*_gene_counts.txt | sed 's/.*\///;s/_gene_counts.txt//' | sort > $OUTPUT_DIR/sample_list.txt
sample_count=$(wc -l < $OUTPUT_DIR/sample_list.txt)

echo "Processing $sample_count samples..."

# Create a temporary directory for processing
TEMP_DIR="./temp_merge"
mkdir -p $TEMP_DIR

# Step 1: Create sample count files in better format
echo "Step 1: Preprocessing sample files..."
counter=0
while read sample; do
    counter=$((counter + 1))
    echo -n "."
    if [ $((counter % 10)) -eq 0 ]; then
        echo " $counter/$sample_count"
    fi
    
    # Create simplified file: gene_id, count
    awk '{print $4 "\t" $7}' "$OUTPUT_DIR/${sample}_gene_counts.txt" > "$TEMP_DIR/${sample}.simple.txt"
    
done < $OUTPUT_DIR/sample_list.txt
echo " Preprocessing completed."

# Step 2: Get all unique gene IDs
echo "Step 2: Collecting all gene IDs..."
awk '{print $1}' $OUTPUT_DIR/Tco-230_gene_counts.txt > $TEMP_DIR/all_genes.txt
total_genes=$(wc -l < $TEMP_DIR/all_genes.txt)
echo "Total genes: $total_genes"

# Step 3: Create header
echo "Step 3: Creating output file..."
echo -n "GeneID" > $OUTPUT_DIR/$FINAL_COUNTS_FILE
while read sample; do
    echo -n ",$sample" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
done < $OUTPUT_DIR/sample_list.txt
echo "" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE

# Step 4: Process in smaller batches to avoid memory issues
echo "Step 4: Merging counts (in batches of 1000 genes)..."
batch_size=1000
total_batches=$(( (total_genes + batch_size - 1) / batch_size ))

for ((batch=1; batch<=total_batches; batch++)); do
    start_line=$(( (batch-1) * batch_size + 1 ))
    end_line=$(( batch * batch_size ))
    if [ $end_line -gt $total_genes ]; then
        end_line=$total_genes
    fi
    
    echo "Processing batch $batch/$total_batches (genes $start_line-$end_line)..."
    
    # Extract batch of genes
    sed -n "${start_line},${end_line}p" $TEMP_DIR/all_genes.txt > $TEMP_DIR/batch_genes.txt
    
    # Process this batch
    while read gene_id; do
        echo -n "$gene_id" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
        
        # Get count for each sample
        while read sample; do
            count_file="$TEMP_DIR/${sample}.simple.txt"
            count=$(awk -v gene="$gene_id" '$1 == gene {print $2; exit}' "$count_file")
            if [ -z "$count" ]; then
                count="0"
            fi
            echo -n ",$count" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
        done < $OUTPUT_DIR/sample_list.txt
        
        echo "" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
        
    done < $TEMP_DIR/batch_genes.txt
done

# Cleanup
rm -rf $TEMP_DIR

echo "✅ Efficient merge completed: $OUTPUT_DIR/$FINAL_COUNTS_FILE"
echo "File size: $(ls -lh $OUTPUT_DIR/$FINAL_COUNTS_FILE | awk '{print $5}')"

# Show summary
echo ""
echo "First 3 lines:"
head -3 $OUTPUT_DIR/$FINAL_COUNTS_FILE | column -t -s,
