    1      }
    2  }
    3  NR>1 {
    4      # 收集数据用于统计
    5      sequences[NR] = $seq_col
    6      duplicates[NR] = $dup_col
    7      gc_content[NR] = $gc_col
    8      fail_rate[NR] = $fail_col
    9      total_seqs += $seq_col
   10      count++
   11  }
   12  END {
   13      # 序列数量分析
   14      n = asort(sequences)
   15      min_seq = sequences[1]
   16      max_seq = sequences[n]
   17      median_seq = (n % 2 == 1) ? sequences[(n+1)/2] : (sequences[n/2] + sequences[n/2+1])/2
   18      
   19      print "SEQUENCE QUANTITY ANALYSIS:"
   20      print "Total samples: " count
   21      print "Total sequences: " total_seqs
   22      print "Mean sequences per sample: " sprintf("%.0f", total_seqs/count)
   23      print "Median sequences per sample: " sprintf("%.0f", median_seq)
   24      print "Range: " min_seq " - " max_seq
   25      print ""
   26      
   27      # 序列数量质量评估
   28      within_range = 0
   29      for(i=1;i<=n;i++) {
   30          if(sequences[i] >= 180000 && sequences[i] <= 220000) within_range++
   31      }
   32      
   33      print "SEQUENCE COUNT QUALITY:"
   34      print "Expected: 200,000 ± 10% (180,000 - 220,000)"
   35      print "Samples within range: " within_range "/" count " (" sprintf("%.1f", within_range/count*100) "%)"
   36      
   37      if(within_range/count >= 0.9) {
   38          print "✅ EXCELLENT: Sequence counts consistent across samples"
   39      } else if(within_range/count >= 0.8) {
   40          print "⚠️ ACCEPTABLE: Minor variations in sequence counts"
   41      } else {
   42          print "❌ POOR: Significant variation in sequence counts"
   43      }
   44      print ""
   45      
   46      # 重复率分析
   47      n_dup = asort(duplicates)
   48      print "DUPLICATION RATE ANALYSIS:"
   49      print "RNAseq expected range: 20-50%"
   50      low_dup = 0; acceptable_dup = 0; high_dup = 0
   51      for(i=1;i<=n_dup;i++) {
   52          if(duplicates[i] < 20) low_dup++
   53          else if(duplicates[i] <= 40) acceptable_dup++
   54          else high_dup++
   55      }
   56      print "Low duplication (<20%): " low_dup " samples"
   57      print "Acceptable duplication (20-40%): " acceptable_dup " samples"
   58      print "High duplication (>40%): " high_dup " samples"
   59      print ""
   60      
   61      # GC含量分析
   62      print "GC CONTENT ANALYSIS:"
   63      print "T. congolense expected: ~50-55%"
   64      ideal_gc = 0; acceptable_gc = 0; abnormal_gc = 0
   65      for(i=1;i<=n;i++) {
   66          if(gc_content[i] >= 48 && gc_content[i] <= 55) ideal_gc++
   67          else if(gc_content[i] >= 45 && gc_content[i] <= 57) acceptable_gc++
   68          else abnormal_gc++
   69      }
   70      print "Ideal GC (48-55%): " ideal_gc " samples"
   71      print "Acceptable GC (45-57%): " acceptable_gc " samples" 
   72      print "Abnormal GC: " abnormal_gc " samples"
   73      print ""
   74      
   75      # FastQC失败率分析
   76      print "FASTQC FAILURE RATE:"
   77      perfect = 0; good = 0; problems = 0
   78      for(i=1;i<=n;i++) {
   79          if(fail_rate[i] == 0) perfect++
   80          else if(fail_rate[i] <= 2) good++
   81          else problems++
   82      }
   83      print "Perfect (0 failures): " perfect " samples"
   84      print "Good (1-2 failures): " good " samples"
   85      print "Multiple problems (>2 failures): " problems " samples"
   86      
   87  }' multiqc_general_stats.txt
   88  which bowtie2 hisat2
   89  pwd
   90  cd .
   91  cd..
   92  cd ~
   93  pwd
   94  cd CIA/MyFirstPipeline
   95  ls -al
   96  ls -la Tcongo_genome/
   97  file Tcongo_genome/*
   98  GENOME_DIR="./Tcongo_genome"
   99  # 假设基因组文件在Tcongo_genome目录中，需要确认具体文件名
  100  GENOME_FASTA="$GENOME_DIR/TriTrypDB-46_TcongolenseIL3000_2019.fasta"  # 可能需要调整
  101  OUTPUT_DIR="./alignment_results"
  102  THREADS=8
  103  # 创建输出目录
  104  mkdir -p $OUTPUT_DIR
  105  echo "Starting alignment with bowtie2..."
  106  # 1. 首先检查基因组文件
  107  if [ ! -f "$GENOME_FASTA" ]; then     echo "Genome fasta file not found at: $GENOME_FASTA";     echo "Available files in Tcongo_genome:";     ls -la $GENOME_DIR/;     exit 1; fi
  108  pwd
  109  ls -la /localdisk/data/BPSM/MyFirstPipeline/TriTrypDB-46_TcongolenseIL3000_2019.bed
  110  head -5 /localdisk/data/BPSM/MyFirstPipeline/TriTrypDB-46_TcongolenseIL3000_2019.bed
  111  #!/bin/bash
  112  # filename: generate_gene_counts.sh
  113  # 设置路径
  114  BEDFILE="/localdisk/data/BPSM/MyFirstPipeline/TriTrypDB-46_TcongolenseIL3000_2019.bed"
  115  ALIGNMENT_DIR="./alignment_results"
  116  OUTPUT_DIR="./count_results"
  117  THREADS=8
  118  # 创建输出目录
  119  mkdir -p $OUTPUT_DIR
  120  echo "开始使用bedtools进行基因计数..."
  121  # 检查BAM文件是否存在
  122  if [ ! -f "$ALIGNMENT_DIR/Tco-230.sorted.bam" ]; then     echo "错误: 未找到BAM文件，请先完成序列比对";     exit 1; fi
  123  # 为每个样本生成基因计数
  124  for bam_file in $ALIGNMENT_DIR/*.sorted.bam; do     sample_name=$(basename $bam_file .sorted.bam);          echo "==================================================================";     echo "正在处理样本: $sample_name";     
  125      bedtools multicov         -bams $bam_file         -bed $BEDFILE         -q 10         > $OUTPUT_DIR/${sample_name}_gene_counts.txt;          if [ $? -eq 0 ]; then
  126          total_reads=$(samtools view -c $bam_file);         mapped_genes=$(wc -l < $OUTPUT_DIR/${sample_name}_gene_counts.txt);         assigned_reads=$(awk '{sum += $7} END {print sum}' $OUTPUT_DIR/${sample_name}_gene_counts.txt);                  echo "✅ 完成: $sample_name";         echo "   总读数: $total_reads";         echo "   分配到基因的读数: $assigned_reads";         echo "   有表达的基因数: $mapped_genes";     else         echo "❌ 错误: $sample_name 计数失败";     fi; done
  127  echo "=================================================================="
  128  echo "所有基因计数完成!"
  129  head -3 count_results/Tco-230_gene_counts.txt
  130  head -3 /localdisk/data/BPSM/MyFirstPipeline/TriTrypDB-46_TcongolenseIL3000_2019.bed
  131  #!/bin/bash
  132  # filename: calculate_group_means.sh
  133  COUNT_FILE="./count_results/all_samples_gene_counts.csv"
  134  BEDFILE="/localdisk/data/BPSM/MyFirstPipeline/TriTrypDB-46_TcongolenseIL3000_2019.bed"
  135  OUTPUT_DIR="./group_means_results"
  136  mkdir -p $OUTPUT_DIR
  137  echo "Starting to calculate group means for gene expression..."
  138  # Check input files
  139  if [ ! -f "$COUNT_FILE" ]; then     echo "Error: Count file $COUNT_FILE not found";     exit 1; fi
  140  ls -la Tcongo_genome/
  141  cd CIA/MyFirstPepeline
  142  pwd
  143  cd CIA/MyFirstPepeline/
  144  cd ~/CIA/MyFirstPepeline/
  145  pwd
  146  cd ${HOME}/s2886730/CIA/MyFirstPepeline/
  147  cd ${HOME}/s2886730/CIA/
  148  cd ${HOME}/s2886730/CIA
  149  cd /${HOME}/s2886730/CIA
  150  cd CIA
  151  cd MyFirstPipeline
  152  ls -la Tcongo_genome/
  153  file Tcongo_genome/*
  154  gunzip -c Tcongo_genome/TriTrypDB-46_TcongolenseIL3000_2019_Genome.fasta.gz > Tcongo_genome/IL3000_genome.fasta\
  155  gunzip -c Tcongo_genome/TriTrypDB-46_TcongolenseIL3000_2019_Genome.fasta.gz > Tcongo_genome/IL3000_genome.fasta
  156  ls -lh Tcongo_genome/IL3000_genome.fasta
  157  # 设置路径
  158  GENOME_DIR="./Tcongo_genome"
  159  GENOME_FASTA="$GENOME_DIR/IL3000_genome.fasta"  # 解压后的文件
  160  OUTPUT_DIR="./alignment_results"
  161  THREADS=8
  162  # 创建输出目录
  163  mkdir -p $OUTPUT_DIR
  164  echo "Starting RNAseq alignment with HISAT2..."
  165  # 1. 检查基因组文件
  166  if [ ! -f "$GENOME_FASTA" ]; then     echo "Error: Genome fasta file not found at: $GENOME_FASTA";     echo "Please run: gunzip -c Tcongo_genome/TriTrypDB-46_TcongolenseIL3000_2019_Genome.fasta.gz > Tcongo_genome/IL3000_genome.fasta";     exit 1; fi
  167  # 2. 为HISAT2构建基因组索引
  168  echo "Building HISAT2 index..."
  169  hisat2-build -p $THREADS $GENOME_FASTA $GENOME_DIR/IL3000_index
  170  # 3. 对每个样本进行比对
  171  for r1_file in fastq/*_1.fq.gz; do     if [ ! -f "$r1_file" ]; then         echo "No R1 files found in fastq directory";         break;     fi;          sample_name=$(basename $r1_file _1.fq.gz);     r2_file="fastq/${sample_name}_2.fq.gz";          echo "==================================================================";     echo "Aligning $sample_name...";     
  172      if [ ! -f "$r2_file" ]; then         echo "Error: R2 file not found: $r2_file";         continue;     fi;     
  173      hisat2         -x $GENOME_DIR/IL3000_index         -1 $r1_file         -2 $r2_file         --no-unal         --threads $THREADS         --rna-strandness RF         --summary-file $OUTPUT_DIR/${sample_name}_alignment_summary.txt         -S $OUTPUT_DIR/${sample_name}.sam;     
  174      if [ $? -ne 0 ]; then         echo "Error: HISAT2 alignment failed for $sample_name";         continue;     fi;     
  175      echo "Converting SAM to sorted BAM...";     samtools view -@ $THREADS -bS $OUTPUT_DIR/${sample_name}.sam |     samtools sort -@ $THREADS -o $OUTPUT_DIR/${sample_name}.sorted.bam;     
  176      echo "Indexing BAM file...";     samtools index $OUTPUT_DIR/${sample_name}.sorted.bam;     
  177      rm $OUTPUT_DIR/${sample_name}.sam;     
  178      total_reads=$(samtools view -c $OUTPUT_DIR/${sample_name}.sorted.bam);     mapped_reads=$(samtools view -c -F 4 $OUTPUT_DIR/${sample_name}.sorted.bam);     mapping_rate=$(echo "scale=2; $mapped_reads * 100 / $total_reads" | bc);          echo "✅ Completed: $sample_name - Mapping rate: $mapping_rate%"; done
  179  [200~$
  180  bash
  181  #!/bin/bash
  182  # filename: run_complete_alignment.sh
  183  echo "=== RNAseq Alignment Pipeline ==="
  184  # 步骤1: 解压基因组
  185  echo "1. Decompressing genome file..."
  186  if [ ! -f "Tcongo_genome/IL3000_genome.fasta" ]; then     gunzip -c Tcongo_genome/TriTrypDB-46_TcongolenseIL3000_2019_Genome.fasta.gz > Tcongo_genome/IL3000_genome.fasta;     echo "✅ Genome decompressed"; else     echo "✅ Genome already decompressed"; fi
  187  # 步骤2: 运行比对
  188  echo "2. Running HISAT2 alignment..."
  189  chmod +x align_hisat2_complete.sh
  190  ./align_hisat2_complete.sh
  191  # 步骤3: 生成比对统计
  192  echo "3. Generating alignment statistics..."
  193  ./alignment_stats.sh
  194  echo "=== Pipeline Complete ==="
  195  ls -la
  196  ls -la alignment_results/ 2>/dev/null || echo "No alignment_results directory"
  197  ls -la count_results/ 2>/dev/null || echo "No count_results directory"
  198  s2886730@bioinfmsc7:~/CIA/MyFirstPipeline$ ls -la count_results/ 2>/dev/null || echo "No coun          t_results directory"
  199  total 47040
  200  drwxr-xr-x  2 s2886730 g_s2886730    4096 Oct  8 20:19 .
  201  drwxr-xr-x 10 s2886730 g_s2886730     256 Oct  8 20:26 ..
  202  -rw-r--r--  1 s2886730 g_s2886730 1001023 Oct  8 20:14 Tco-106_gene_counts.txt
  203  -rw-r--r--  1 s2886730 g_s2886730 1001500 Oct  8 20:14 Tco-122_gene_counts.txt
  204  -rw-r--r--  1 s2886730 g_s2886730 1001426 Oct  8 20:14 Tco-159_gene_counts.txt
  205  -rw-r--r--  1 s2886730 g_s2886730 1001327 Oct  8 20:14 Tco-160_gene_counts.txt
  206  -rw-r--r--  1 s2886730 g_s2886730  997970 Oct  8 20:14 Tco-17_gene_counts.txt
  207  -rw-r--r--  1 s2886730 g_s2886730 1000533 Oct  8 20:14 Tco-182_gene_counts.txt
  208  -rw-r--r--  1 s2886730 g_s2886730 1001249 Oct  8 20:14 Tco-21_gene_counts.txt
  209  -rw-r--r--  1 s2886730 g_s2886730 1001119 Oct  8 20:14 Tco-229_gene_counts.txt
  210  -rw-r--r--  1 s2886730 g_s2886730 1000748 Oct  8 20:15 Tco-230_gene_counts.txt
  211  -rw-r--r--  1 s2886730 g_s2886730 1001327 Oct  8 20:15 Tco-28_gene_counts.txt
  212  -rw-r--r--  1 s2886730 g_s2886730 1001215 Oct  8 20:15 Tco-290_gene_counts.txt
  213  -rw-r--r--  1 s2886730 g_s2886730 1001471 Oct  8 20:15 Tco-362_gene_counts.txt
  214  -rw-r--r--  1 s2886730 g_s2886730 1001196 Oct  8 20:15 Tco-392_gene_counts.txt
  215  -rw-r--r--  1 s2886730 g_s2886730 1001118 Oct  8 20:15 Tco-397_gene_counts.txt
  216  -rw-r--r--  1 s2886730 g_s2886730 1001532 Oct  8 20:15 Tco-398_gene_counts.txt
  217  -rw-r--r--  1 s2886730 g_s2886730 1000981 Oct  8 20:15 Tco-427_gene_counts.txt
  218  -rw-r--r--  1 s2886730 g_s2886730 1001517 Oct  8 20:16 Tco-444_gene_counts.txt
  219  -rw-r--r--  1 s2886730 g_s2886730 1001091 Oct  8 20:16 Tco-467_gene_counts.txt
  220  -rw-r--r--  1 s2886730 g_s2886730 1001456 Oct  8 20:16 Tco-480_gene_counts.txt
  221  -rw-r--r--  1 s2886730 g_s2886730 1001374 Oct  8 20:16 Tco-483_gene_counts.txt
  222  -rw-r--r--  1 s2886730 g_s2886730 1001117 Oct  8 20:16 Tco-486_gene_counts.txt
  223  -rw-r--r--  1 s2886730 g_s2886730 1000974 Oct  8 20:16 Tco-503_gene_counts.txt
  224  -rw-r--r--  1 s2886730 g_s2886730 1000679 Oct  8 20:16 Tco-522_gene_counts.txt
  225  -rw-r--r--  1 s2886730 g_s2886730 1001422 Oct  8 20:16 Tco-549_gene_counts.txt
  226  -rw-r--r--  1 s2886730 g_s2886730  999856 Oct  8 20:17 Tco-580_gene_counts.txt
  227  -rw-r--r--  1 s2886730 g_s2886730 1001312 Oct  8 20:17 Tco-582_gene_counts.txt
  228  -rw-r--r--  1 s2886730 g_s2886730 1000981 Oct  8 20:17 Tco-596_gene_counts.txt
  229  -rw-r--r--  1 s2886730 g_s2886730 1001295 Oct  8 20:17 Tco-613_gene_counts.txt
  230  -rw-r--r--  1 s2886730 g_s2886730 1000952 Oct  8 20:17 Tco-622_gene_counts.txt
  231  -rw-r--r--  1 s2886730 g_s2886730 1001379 Oct  8 20:17 Tco-633_gene_counts.txt
  232  -rw-r--r--  1 s2886730 g_s2886730 1000511 Oct  8 20:17 Tco-674_gene_counts.txt
  233  -rw-r--r--  1 s2886730 g_s2886730 1001097 Oct  8 20:17 Tco-702_gene_counts.txt
  234  -rw-r--r--  1 s2886730 g_s2886730 1000755 Oct  8 20:18 Tco-719_gene_counts.txt
  235  -rw-r--r--  1 s2886730 g_s2886730 1000690 Oct  8 20:18 Tco-752_gene_counts.txt
  236  -rw-r--r--  1 s2886730 g_s2886730 1001603 Oct  8 20:18 Tco-754_gene_counts.txt
  237  -rw-r--r--  1 s2886730 g_s2886730 1001303 Oct  8 20:18 Tco-757_gene_counts.txt
  238  -rw-r--r--  1 s2886730 g_s2886730 1001155 Oct  8 20:18 Tco-76_gene_counts.txt
  239  -rw-r--r--  1 s2886730 g_s2886730 1001058 Oct  8 20:18 Tco-851_gene_counts.txt
  240  -rw-r--r--  1 s2886730 g_s2886730 1000800 Oct  8 20:18 Tco-859_gene_counts.txt
  241  -rw-r--r--  1 s2886730 g_s2886730 1000961 Oct  8 20:18 Tco-86_gene_counts.txt
  242  -rw-r--r--  1 s2886730 g_s2886730 1001099 Oct  8 20:19 Tco-878_gene_counts.txt
  243  -rw-r--r--  1 s2886730 g_s2886730 1001174 Oct  8 20:19 Tco-892_gene_counts.txt
  244  -rw-r--r--  1 s2886730 g_s2886730 1001024 Oct  8 20:19 Tco-907_gene_counts.txt
  245  -rw-r--r--  1 s2886730 g_s2886730 1001335 Oct  8 20:19 Tco-935_gene_counts.txt
  246  -rw-r--r--  1 s2886730 g_s2886730 1001142 Oct  8 20:19 Tco-949_gene_counts.txt
  247  -rw-r--r--  1 s2886730 g_s2886730 1000606 Oct  8 20:19 Tco-960_gene_counts.txt
  248  -rw-r--r--  1 s2886730 g_s2886730 1001532 Oct  8 20:19 Tco-964_gene_counts.txt
  249  -rw-r--r--  1 s2886730 g_s2886730 1001318 Oct  8 20:19 Tco-999_gene_counts.txt
  250  cat > merge_gene_counts.sh << 'EOF'
  251  #!/bin/bash
  252  # filename: merge_gene_counts.sh
  253  OUTPUT_DIR="./count_results"
  254  FINAL_COUNTS_FILE="all_samples_gene_counts.csv"
  255  echo "Starting to merge all sample gene counts..."
  256  # Check if count files exist
  257  if [ ! -f "$OUTPUT_DIR/Tco-230_gene_counts.txt" ]; then
  258      echo "Error: Gene count files not found. Please run generate_gene_counts.sh first."
  259      exit 1
  260  fi
  261  # Create merged count matrix
  262  echo "Creating merged count matrix..."
  263  # Get all sample names from count files
  264  ls $OUTPUT_DIR/*_gene_counts.txt | sed 's/.*\///;s/_gene_counts.txt//' | sort > $OUTPUT_DIR/sample_list.txt
  265  # Create header
  266  echo -n "GeneID" > $OUTPUT_DIR/$FINAL_COUNTS_FILE
  267  while read sample; do
  268      echo -n ",$sample" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
  269  done < $OUTPUT_DIR/sample_list.txt
  270  echo "" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
  271  # Extract gene IDs from first file (4th column is gene ID)
  272  awk '{print $4}' $OUTPUT_DIR/Tco-230_gene_counts.txt > $OUTPUT_DIR/gene_ids.txt
  273  # Count total genes and samples
  274  total_genes=$(wc -l < $OUTPUT_DIR/gene_ids.txt)
  275  total_samples=$(wc -l < $OUTPUT_DIR/sample_list.txt)
  276  echo "Processing $total_genes genes across $total_samples samples..."
  277  # Process each gene
  278  counter=0
  279  while read gene_id; do
  280      counter=$((counter + 1))
  281      if [ $((counter % 1000)) -eq 0 ]; then
  282          echo "Processed $counter genes..."
  283      fi
  284      
  285      echo -n "$gene_id" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
  286      
  287      # Get count for this gene from each sample
  288      while read sample; do
  289          count_file="$OUTPUT_DIR/${sample}_gene_counts.txt"
  290          # Extract count for this gene (7th column)
  291          count=$(awk -v gene="$gene_id" '$4 == gene {print $7}' "$count_file")
  292          if [ -z "$count" ]; then
  293              count="0"
  294          fi
  295          echo -n ",$count" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
  296      done < $OUTPUT_DIR/sample_list.txt
  297      
  298      echo "" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
  299      
  300  done < $OUTPUT_DIR/gene_ids.txt
  301  echo "✅ Merged counts file created: $OUTPUT_DIR/$FINAL_COUNTS_FILE"
  302  # Show summary
  303  echo ""
  304  echo "Summary:"
  305  echo "Total genes: $(wc -l < $OUTPUT_DIR/gene_ids.txt)"
  306  echo "Total samples: $(wc -l < $OUTPUT_DIR/sample_list.txt)"
  307  echo "File size: $(ls -lh $OUTPUT_DIR/$FINAL_COUNTS_FILE | awk '{print $5}')"
  308  # Show first few lines
  309  echo ""
  310  echo "First 3 lines of merged file:"
  311  head -3 $OUTPUT_DIR/$FINAL_COUNTS_FILE | column -t -s,
  312  EOF
  313  # 运行合并脚本
  314  chmod +x merge_gene_counts.sh
  315  ./merge_gene_counts.sh
  316  cat > merge_gene_counts_simple.sh << 'EOF'
  317  #!/bin/bash
  318  # filename: merge_gene_counts_simple.sh
  319  OUTPUT_DIR="./count_results"
  320  FINAL_COUNTS_FILE="all_samples_gene_counts.csv"
  321  echo "Using simple merge method..."
  322  # Get sample list
  323  ls $OUTPUT_DIR/*_gene_counts.txt | sed 's/.*\///;s/_gene_counts.txt//' | sort > $OUTPUT_DIR/sample_list.txt
  324  # Create header
  325  echo -n "GeneID" > $OUTPUT_DIR/$FINAL_COUNTS_FILE
  326  while read sample; do
  327      echo -n ",$sample" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
  328  done < $OUTPUT_DIR/sample_list.txt
  329  echo "" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
  330  # Use the first file as base and join others
  331  base_file="$OUTPUT_DIR/Tco-230_gene_counts.txt"
  332  echo "Merging files (this may take a few minutes)..."
  333  awk -F'\t' -v output="$OUTPUT_DIR/$FINAL_COUNTS_FILE" -v sample_list="$OUTPUT_DIR/sample_list.txt" '
  334  BEGIN {
  335      # Read sample list
  336      sample_count = 0
  337      while ((getline sample < sample_list) > 0) {
  338          samples[++sample_count] = sample
  339      }
  340      close(sample_list)
  341      
  342      # Initialize counts array
  343      for (i=1; i<=sample_count; i++) {
  344          sample_file = "count_results/" samples[i] "_gene_counts.txt"
  345          j = 0
  346          while ((getline line < sample_file) > 0) {
  347              split(line, fields, "\t")
  348              gene_id = fields[4]
  349              count = fields[7]
  350              counts[gene_id, i] = count
  351              j++
  352              if (j == 1) print "Processing " samples[i] ": " j " genes..." > "/dev/stderr"
  353          }
  354          close(sample_file)
  355          print "Completed " samples[i] ": " j " genes" > "/dev/stderr"
  356      }
  357  }
  358  {
  359      gene_id = $4
  360      printf "%s", gene_id >> output
  361      for (i=1; i<=sample_count; i++) {
  362          count = counts[gene_id, i]
  363          if (count == "") count = "0"
  364          printf ",%s", count >> output
  365      }
  366      printf "\n" >> output
  367  }
  368  ' "$base_file"
  369  echo "✅ Simple merge completed: $OUTPUT_DIR/$FINAL_COUNTS_FILE"
  370  EOF
  371  chmod +x merge_gene_counts_simple.sh
  372  cat > merge_gene_counts_efficient.sh << 'EOF'
  373  #!/bin/bash
  374  # filename: merge_gene_counts_efficient.sh
  375  OUTPUT_DIR="./count_results"
  376  FINAL_COUNTS_FILE="all_samples_gene_counts.csv"
  377  echo "Starting efficient merge of gene counts..."
  378  # Check if count files exist
  379  if [ ! -f "$OUTPUT_DIR/Tco-230_gene_counts.txt" ]; then
  380      echo "Error: Gene count files not found."
  381      exit 1
  382  fi
  383  # Get sample list
  384  ls $OUTPUT_DIR/*_gene_counts.txt | sed 's/.*\///;s/_gene_counts.txt//' | sort > $OUTPUT_DIR/sample_list.txt
  385  sample_count=$(wc -l < $OUTPUT_DIR/sample_list.txt)
  386  echo "Processing $sample_count samples..."
  387  # Create a temporary directory for processing
  388  TEMP_DIR="./temp_merge"
  389  mkdir -p $TEMP_DIR
  390  # Step 1: Create sample count files in better format
  391  echo "Step 1: Preprocessing sample files..."
  392  counter=0
  393  while read sample; do
  394      counter=$((counter + 1))
  395      echo -n "."
  396      if [ $((counter % 10)) -eq 0 ]; then
  397          echo " $counter/$sample_count"
  398      fi
  399      
  400      # Create simplified file: gene_id, count
  401      awk '{print $4 "\t" $7}' "$OUTPUT_DIR/${sample}_gene_counts.txt" > "$TEMP_DIR/${sample}.simple.txt"
  402      
  403  done < $OUTPUT_DIR/sample_list.txt
  404  echo " Preprocessing completed."
  405  # Step 2: Get all unique gene IDs
  406  echo "Step 2: Collecting all gene IDs..."
  407  awk '{print $1}' $OUTPUT_DIR/Tco-230_gene_counts.txt > $TEMP_DIR/all_genes.txt
  408  total_genes=$(wc -l < $TEMP_DIR/all_genes.txt)
  409  echo "Total genes: $total_genes"
  410  # Step 3: Create header
  411  echo "Step 3: Creating output file..."
  412  echo -n "GeneID" > $OUTPUT_DIR/$FINAL_COUNTS_FILE
  413  while read sample; do
  414      echo -n ",$sample" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
  415  done < $OUTPUT_DIR/sample_list.txt
  416  echo "" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
  417  # Step 4: Process in smaller batches to avoid memory issues
  418  echo "Step 4: Merging counts (in batches of 1000 genes)..."
  419  batch_size=1000
  420  total_batches=$(( (total_genes + batch_size - 1) / batch_size ))
  421  for ((batch=1; batch<=total_batches; batch++)); do
  422      start_line=$(( (batch-1) * batch_size + 1 ))
  423      end_line=$(( batch * batch_size ))
  424      if [ $end_line -gt $total_genes ]; then
  425          end_line=$total_genes
  426      fi
  427      
  428      echo "Processing batch $batch/$total_batches (genes $start_line-$end_line)..."
  429      
  430      # Extract batch of genes
  431      sed -n "${start_line},${end_line}p" $TEMP_DIR/all_genes.txt > $TEMP_DIR/batch_genes.txt
  432      
  433      # Process this batch
  434      while read gene_id; do
  435          echo -n "$gene_id" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
  436          
  437          # Get count for each sample
  438          while read sample; do
  439              count_file="$TEMP_DIR/${sample}.simple.txt"
  440              count=$(awk -v gene="$gene_id" '$1 == gene {print $2; exit}' "$count_file")
  441              if [ -z "$count" ]; then
  442                  count="0"
  443              fi
  444              echo -n ",$count" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
  445          done < $OUTPUT_DIR/sample_list.txt
  446          
  447          echo "" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
  448          
  449      done < $TEMP_DIR/batch_genes.txt
  450  done
  451  # Cleanup
  452  rm -rf $TEMP_DIR
  453  echo "✅ Efficient merge completed: $OUTPUT_DIR/$FINAL_COUNTS_FILE"
  454  echo "File size: $(ls -lh $OUTPUT_DIR/$FINAL_COUNTS_FILE | awk '{print $5}')"
  455  # Show summary
  456  echo ""
  457  echo "First 3 lines:"
  458  head -3 $OUTPUT_DIR/$FINAL_COUNTS_FILE | column -t -s,
  459  EOF
  460  chmod +x merge_gene_counts_efficient.sh
  461  ./merge_gene_counts_efficient.sh
  462  ls -lh count_results/all_samples_gene_counts.csv
  463  cd CIA/MyFirstPipeline/
  464  git init
  465  git log
  466  git -log
  467  git -log --oneline
  468  history
  469  history > my_Pipeline_script.sh
