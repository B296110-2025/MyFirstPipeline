}
}
NR>1 {
# 收集数据用于统计
sequences[NR] = $seq_col
duplicates[NR] = $dup_col
gc_content[NR] = $gc_col
fail_rate[NR] = $fail_col
total_seqs += $seq_col
count++
}
END {
# 序列数量分析
n = asort(sequences)
min_seq = sequences[1]
max_seq = sequences[n]
median_seq = (n % 2 == 1) ? sequences[(n+1)/2] : (sequences[n/2] + sequences[n/2+1])/2

print "SEQUENCE QUANTITY ANALYSIS:"
print "Total samples: " count
print "Total sequences: " total_seqs
print "Mean sequences per sample: " sprintf("%.0f", total_seqs/count)
print "Median sequences per sample: " sprintf("%.0f", median_seq)
print "Range: " min_seq " - " max_seq
print ""

# 序列数量质量评估
within_range = 0
for(i=1;i<=n;i++) {
if(sequences[i] >= 180000 && sequences[i] <= 220000) within_range++
}

print "SEQUENCE COUNT QUALITY:"
print "Expected: 200,000 ± 10% (180,000 - 220,000)"
print "Samples within range: " within_range "/" count " (" sprintf("%.1f", within_range/count*100) "%)"

if(within_range/count >= 0.9) {
print "✅ EXCELLENT: Sequence counts consistent across samples"
} else if(within_range/count >= 0.8) {
print "⚠️ ACCEPTABLE: Minor variations in sequence counts"
} else {
print "❌ POOR: Significant variation in sequence counts"
}
print ""

# 重复率分析
n_dup = asort(duplicates)
print "DUPLICATION RATE ANALYSIS:"
print "RNAseq expected range: 20-50%"
low_dup = 0; acceptable_dup = 0; high_dup = 0
for(i=1;i<=n_dup;i++) {
if(duplicates[i] < 20) low_dup++
else if(duplicates[i] <= 40) acceptable_dup++
else high_dup++
}
print "Low duplication (<20%): " low_dup " samples"
print "Acceptable duplication (20-40%): " acceptable_dup " samples"
print "High duplication (>40%): " high_dup " samples"
print ""

# GC含量分析
print "GC CONTENT ANALYSIS:"
print "T. congolense expected: ~50-55%"
ideal_gc = 0; acceptable_gc = 0; abnormal_gc = 0
for(i=1;i<=n;i++) {
if(gc_content[i] >= 48 && gc_content[i] <= 55) ideal_gc++
else if(gc_content[i] >= 45 && gc_content[i] <= 57) acceptable_gc++
else abnormal_gc++
}
print "Ideal GC (48-55%): " ideal_gc " samples"
print "Acceptable GC (45-57%): " acceptable_gc " samples" 
print "Abnormal GC: " abnormal_gc " samples"
print ""

# FastQC失败率分析
print "FASTQC FAILURE RATE:"
perfect = 0; good = 0; problems = 0
for(i=1;i<=n;i++) {
if(fail_rate[i] == 0) perfect++
else if(fail_rate[i] <= 2) good++
else problems++
}
print "Perfect (0 failures): " perfect " samples"
print "Good (1-2 failures): " good " samples"
print "Multiple problems (>2 failures): " problems " samples"

}' multiqc_general_stats.txt
which bowtie2 hisat2
pwd
cd .
cd..
cd ~
pwd
cd CIA/MyFirstPipeline
ls -al
ls -la Tcongo_genome/
file Tcongo_genome/*
GENOME_DIR="./Tcongo_genome"
# 假设基因组文件在Tcongo_genome目录中，需要确认具体文件名
GENOME_FASTA="$GENOME_DIR/TriTrypDB-46_TcongolenseIL3000_2019.fasta"  # 可能需要调整
OUTPUT_DIR="./alignment_results"
THREADS=8
# 创建输出目录
mkdir -p $OUTPUT_DIR
echo "Starting alignment with bowtie2..."
# 1. 首先检查基因组文件
if [ ! -f "$GENOME_FASTA" ]; then     echo "Genome fasta file not found at: $GENOME_FASTA";     echo "Available files in Tcongo_genome:";     ls -la $GENOME_DIR/;     exit 1; fi
pwd
ls -la /localdisk/data/BPSM/MyFirstPipeline/TriTrypDB-46_TcongolenseIL3000_2019.bed
head -5 /localdisk/data/BPSM/MyFirstPipeline/TriTrypDB-46_TcongolenseIL3000_2019.bed
#!/bin/bash
# filename: generate_gene_counts.sh
# 设置路径
BEDFILE="/localdisk/data/BPSM/MyFirstPipeline/TriTrypDB-46_TcongolenseIL3000_2019.bed"
ALIGNMENT_DIR="./alignment_results"
OUTPUT_DIR="./count_results"
THREADS=8
# 创建输出目录
mkdir -p $OUTPUT_DIR
echo "开始使用bedtools进行基因计数..."
# 检查BAM文件是否存在
if [ ! -f "$ALIGNMENT_DIR/Tco-230.sorted.bam" ]; then     echo "错误: 未找到BAM文件，请先完成序列比对";     exit 1; fi
# 为每个样本生成基因计数
for bam_file in $ALIGNMENT_DIR/*.sorted.bam; do     sample_name=$(basename $bam_file .sorted.bam);          echo "==================================================================";     echo "正在处理样本: $sample_name";     
bedtools multicov         -bams $bam_file         -bed $BEDFILE         -q 10         > $OUTPUT_DIR/${sample_name}_gene_counts.txt;          if [ $? -eq 0 ]; then
total_reads=$(samtools view -c $bam_file);         mapped_genes=$(wc -l < $OUTPUT_DIR/${sample_name}_gene_counts.txt);         assigned_reads=$(awk '{sum += $7} END {print sum}' $OUTPUT_DIR/${sample_name}_gene_counts.txt);                  echo "✅ 完成: $sample_name";         echo "   总读数: $total_reads";         echo "   分配到基因的读数: $assigned_reads";         echo "   有表达的基因数: $mapped_genes";     else         echo "❌ 错误: $sample_name 计数失败";     fi; done
echo "=================================================================="
echo "所有基因计数完成!"
head -3 count_results/Tco-230_gene_counts.txt
head -3 /localdisk/data/BPSM/MyFirstPipeline/TriTrypDB-46_TcongolenseIL3000_2019.bed
#!/bin/bash
# filename: calculate_group_means.sh
COUNT_FILE="./count_results/all_samples_gene_counts.csv"
BEDFILE="/localdisk/data/BPSM/MyFirstPipeline/TriTrypDB-46_TcongolenseIL3000_2019.bed"
OUTPUT_DIR="./group_means_results"
mkdir -p $OUTPUT_DIR
echo "Starting to calculate group means for gene expression..."
# Check input files
if [ ! -f "$COUNT_FILE" ]; then     echo "Error: Count file $COUNT_FILE not found";     exit 1; fi
ls -la Tcongo_genome/
cd CIA/MyFirstPepeline
pwd
cd CIA/MyFirstPepeline/
cd ~/CIA/MyFirstPepeline/
pwd
cd ${HOME}/s2886730/CIA/MyFirstPepeline/
cd ${HOME}/s2886730/CIA/
cd ${HOME}/s2886730/CIA
cd /${HOME}/s2886730/CIA
cd CIA
cd MyFirstPipeline
ls -la Tcongo_genome/
file Tcongo_genome/*
gunzip -c Tcongo_genome/TriTrypDB-46_TcongolenseIL3000_2019_Genome.fasta.gz > Tcongo_genome/IL3000_genome.fasta\
gunzip -c Tcongo_genome/TriTrypDB-46_TcongolenseIL3000_2019_Genome.fasta.gz > Tcongo_genome/IL3000_genome.fasta
ls -lh Tcongo_genome/IL3000_genome.fasta
# 设置路径
GENOME_DIR="./Tcongo_genome"
GENOME_FASTA="$GENOME_DIR/IL3000_genome.fasta"  # 解压后的文件
OUTPUT_DIR="./alignment_results"
THREADS=8
# 创建输出目录
mkdir -p $OUTPUT_DIR
echo "Starting RNAseq alignment with HISAT2..."
# 1. 检查基因组文件
if [ ! -f "$GENOME_FASTA" ]; then     echo "Error: Genome fasta file not found at: $GENOME_FASTA";     echo "Please run: gunzip -c Tcongo_genome/TriTrypDB-46_TcongolenseIL3000_2019_Genome.fasta.gz > Tcongo_genome/IL3000_genome.fasta";     exit 1; fi
# 2. 为HISAT2构建基因组索引
echo "Building HISAT2 index..."
hisat2-build -p $THREADS $GENOME_FASTA $GENOME_DIR/IL3000_index
# 3. 对每个样本进行比对
for r1_file in fastq/*_1.fq.gz; do     if [ ! -f "$r1_file" ]; then         echo "No R1 files found in fastq directory";         break;     fi;          sample_name=$(basename $r1_file _1.fq.gz);     r2_file="fastq/${sample_name}_2.fq.gz";          echo "==================================================================";     echo "Aligning $sample_name...";     
if [ ! -f "$r2_file" ]; then         echo "Error: R2 file not found: $r2_file";         continue;     fi;     
hisat2         -x $GENOME_DIR/IL3000_index         -1 $r1_file         -2 $r2_file         --no-unal         --threads $THREADS         --rna-strandness RF         --summary-file $OUTPUT_DIR/${sample_name}_alignment_summary.txt         -S $OUTPUT_DIR/${sample_name}.sam;     
if [ $? -ne 0 ]; then         echo "Error: HISAT2 alignment failed for $sample_name";         continue;     fi;     
echo "Converting SAM to sorted BAM...";     samtools view -@ $THREADS -bS $OUTPUT_DIR/${sample_name}.sam |     samtools sort -@ $THREADS -o $OUTPUT_DIR/${sample_name}.sorted.bam;     
echo "Indexing BAM file...";     samtools index $OUTPUT_DIR/${sample_name}.sorted.bam;     
rm $OUTPUT_DIR/${sample_name}.sam;     
total_reads=$(samtools view -c $OUTPUT_DIR/${sample_name}.sorted.bam);     mapped_reads=$(samtools view -c -F 4 $OUTPUT_DIR/${sample_name}.sorted.bam);     mapping_rate=$(echo "scale=2; $mapped_reads * 100 / $total_reads" | bc);          echo "✅ Completed: $sample_name - Mapping rate: $mapping_rate%"; done
[200~$
bash
#!/bin/bash
# filename: run_complete_alignment.sh
echo "=== RNAseq Alignment Pipeline ==="
# 步骤1: 解压基因组
echo "1. Decompressing genome file..."
if [ ! -f "Tcongo_genome/IL3000_genome.fasta" ]; then     gunzip -c Tcongo_genome/TriTrypDB-46_TcongolenseIL3000_2019_Genome.fasta.gz > Tcongo_genome/IL3000_genome.fasta;     echo "✅ Genome decompressed"; else     echo "✅ Genome already decompressed"; fi
# 步骤2: 运行比对
echo "2. Running HISAT2 alignment..."
chmod +x align_hisat2_complete.sh
./align_hisat2_complete.sh
# 步骤3: 生成比对统计
echo "3. Generating alignment statistics..."
./alignment_stats.sh
echo "=== Pipeline Complete ==="
ls -la
ls -la alignment_results/ 2>/dev/null || echo "No alignment_results directory"
ls -la count_results/ 2>/dev/null || echo "No count_results directory"
s2886730@bioinfmsc7:~/CIA/MyFirstPipeline$ ls -la count_results/ 2>/dev/null || echo "No coun          t_results directory"
total 47040
drwxr-xr-x  2 s2886730 g_s2886730    4096 Oct  8 20:19 .
drwxr-xr-x 10 s2886730 g_s2886730     256 Oct  8 20:26 ..
-rw-r--r--  1 s2886730 g_s2886730 1001023 Oct  8 20:14 Tco-106_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001500 Oct  8 20:14 Tco-122_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001426 Oct  8 20:14 Tco-159_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001327 Oct  8 20:14 Tco-160_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730  997970 Oct  8 20:14 Tco-17_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1000533 Oct  8 20:14 Tco-182_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001249 Oct  8 20:14 Tco-21_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001119 Oct  8 20:14 Tco-229_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1000748 Oct  8 20:15 Tco-230_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001327 Oct  8 20:15 Tco-28_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001215 Oct  8 20:15 Tco-290_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001471 Oct  8 20:15 Tco-362_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001196 Oct  8 20:15 Tco-392_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001118 Oct  8 20:15 Tco-397_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001532 Oct  8 20:15 Tco-398_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1000981 Oct  8 20:15 Tco-427_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001517 Oct  8 20:16 Tco-444_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001091 Oct  8 20:16 Tco-467_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001456 Oct  8 20:16 Tco-480_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001374 Oct  8 20:16 Tco-483_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001117 Oct  8 20:16 Tco-486_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1000974 Oct  8 20:16 Tco-503_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1000679 Oct  8 20:16 Tco-522_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001422 Oct  8 20:16 Tco-549_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730  999856 Oct  8 20:17 Tco-580_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001312 Oct  8 20:17 Tco-582_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1000981 Oct  8 20:17 Tco-596_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001295 Oct  8 20:17 Tco-613_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1000952 Oct  8 20:17 Tco-622_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001379 Oct  8 20:17 Tco-633_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1000511 Oct  8 20:17 Tco-674_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001097 Oct  8 20:17 Tco-702_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1000755 Oct  8 20:18 Tco-719_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1000690 Oct  8 20:18 Tco-752_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001603 Oct  8 20:18 Tco-754_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001303 Oct  8 20:18 Tco-757_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001155 Oct  8 20:18 Tco-76_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001058 Oct  8 20:18 Tco-851_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1000800 Oct  8 20:18 Tco-859_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1000961 Oct  8 20:18 Tco-86_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001099 Oct  8 20:19 Tco-878_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001174 Oct  8 20:19 Tco-892_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001024 Oct  8 20:19 Tco-907_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001335 Oct  8 20:19 Tco-935_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001142 Oct  8 20:19 Tco-949_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1000606 Oct  8 20:19 Tco-960_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001532 Oct  8 20:19 Tco-964_gene_counts.txt
-rw-r--r--  1 s2886730 g_s2886730 1001318 Oct  8 20:19 Tco-999_gene_counts.txt
cat > merge_gene_counts.sh << 'EOF'
#!/bin/bash
# filename: merge_gene_counts.sh
OUTPUT_DIR="./count_results"
FINAL_COUNTS_FILE="all_samples_gene_counts.csv"
echo "Starting to merge all sample gene counts..."
# Check if count files exist
if [ ! -f "$OUTPUT_DIR/Tco-230_gene_counts.txt" ]; then
echo "Error: Gene count files not found. Please run generate_gene_counts.sh first."
exit 1
fi
# Create merged count matrix
echo "Creating merged count matrix..."
# Get all sample names from count files
ls $OUTPUT_DIR/*_gene_counts.txt | sed 's/.*\///;s/_gene_counts.txt//' | sort > $OUTPUT_DIR/sample_list.txt
# Create header
echo -n "GeneID" > $OUTPUT_DIR/$FINAL_COUNTS_FILE
while read sample; do
echo -n ",$sample" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
done < $OUTPUT_DIR/sample_list.txt
echo "" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
# Extract gene IDs from first file (4th column is gene ID)
awk '{print $4}' $OUTPUT_DIR/Tco-230_gene_counts.txt > $OUTPUT_DIR/gene_ids.txt
# Count total genes and samples
total_genes=$(wc -l < $OUTPUT_DIR/gene_ids.txt)
total_samples=$(wc -l < $OUTPUT_DIR/sample_list.txt)
echo "Processing $total_genes genes across $total_samples samples..."
# Process each gene
counter=0
while read gene_id; do
counter=$((counter + 1))
if [ $((counter % 1000)) -eq 0 ]; then
echo "Processed $counter genes..."
fi

echo -n "$gene_id" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE

# Get count for this gene from each sample
while read sample; do
count_file="$OUTPUT_DIR/${sample}_gene_counts.txt"
# Extract count for this gene (7th column)
count=$(awk -v gene="$gene_id" '$4 == gene {print $7}' "$count_file")
if [ -z "$count" ]; then
count="0"
fi
echo -n ",$count" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
done < $OUTPUT_DIR/sample_list.txt

echo "" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE

done < $OUTPUT_DIR/gene_ids.txt
echo "✅ Merged counts file created: $OUTPUT_DIR/$FINAL_COUNTS_FILE"
# Show summary
echo ""
echo "Summary:"
echo "Total genes: $(wc -l < $OUTPUT_DIR/gene_ids.txt)"
echo "Total samples: $(wc -l < $OUTPUT_DIR/sample_list.txt)"
echo "File size: $(ls -lh $OUTPUT_DIR/$FINAL_COUNTS_FILE | awk '{print $5}')"
# Show first few lines
echo ""
echo "First 3 lines of merged file:"
head -3 $OUTPUT_DIR/$FINAL_COUNTS_FILE | column -t -s,
EOF
# 运行合并脚本
chmod +x merge_gene_counts.sh
./merge_gene_counts.sh
cat > merge_gene_counts_simple.sh << 'EOF'
#!/bin/bash
# filename: merge_gene_counts_simple.sh
OUTPUT_DIR="./count_results"
FINAL_COUNTS_FILE="all_samples_gene_counts.csv"
echo "Using simple merge method..."
# Get sample list
ls $OUTPUT_DIR/*_gene_counts.txt | sed 's/.*\///;s/_gene_counts.txt//' | sort > $OUTPUT_DIR/sample_list.txt
# Create header
echo -n "GeneID" > $OUTPUT_DIR/$FINAL_COUNTS_FILE
while read sample; do
echo -n ",$sample" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
done < $OUTPUT_DIR/sample_list.txt
echo "" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
# Use the first file as base and join others
base_file="$OUTPUT_DIR/Tco-230_gene_counts.txt"
echo "Merging files (this may take a few minutes)..."
awk -F'\t' -v output="$OUTPUT_DIR/$FINAL_COUNTS_FILE" -v sample_list="$OUTPUT_DIR/sample_list.txt" '
BEGIN {
# Read sample list
sample_count = 0
while ((getline sample < sample_list) > 0) {
samples[++sample_count] = sample
}
close(sample_list)

# Initialize counts array
for (i=1; i<=sample_count; i++) {
sample_file = "count_results/" samples[i] "_gene_counts.txt"
j = 0
while ((getline line < sample_file) > 0) {
split(line, fields, "\t")
gene_id = fields[4]
count = fields[7]
counts[gene_id, i] = count
j++
if (j == 1) print "Processing " samples[i] ": " j " genes..." > "/dev/stderr"
}
close(sample_file)
print "Completed " samples[i] ": " j " genes" > "/dev/stderr"
}
}
{
gene_id = $4
printf "%s", gene_id >> output
for (i=1; i<=sample_count; i++) {
count = counts[gene_id, i]
if (count == "") count = "0"
printf ",%s", count >> output
}
printf "\n" >> output
}
' "$base_file"
echo "✅ Simple merge completed: $OUTPUT_DIR/$FINAL_COUNTS_FILE"
EOF
chmod +x merge_gene_counts_simple.sh
cat > merge_gene_counts_efficient.sh << 'EOF'
#!/bin/bash
# filename: merge_gene_counts_efficient.sh
OUTPUT_DIR="./count_results"
FINAL_COUNTS_FILE="all_samples_gene_counts.csv"
echo "Starting efficient merge of gene counts..."
# Check if count files exist
if [ ! -f "$OUTPUT_DIR/Tco-230_gene_counts.txt" ]; then
echo "Error: Gene count files not found."
exit 1
fi
# Get sample list
ls $OUTPUT_DIR/*_gene_counts.txt | sed 's/.*\///;s/_gene_counts.txt//' | sort > $OUTPUT_DIR/sample_list.txt
sample_count=$(wc -l < $OUTPUT_DIR/sample_list.txt)
echo "Processing $sample_count samples..."
# Create a temporary directory for processing
TEMP_DIR="./temp_merge"
mkdir -p $TEMP_DIR
# Step 1: Create sample count files in better format
echo "Step 1: Preprocessing sample files..."
counter=0
while read sample; do
counter=$((counter + 1))
echo -n "."
if [ $((counter % 10)) -eq 0 ]; then
echo " $counter/$sample_count"
fi

# Create simplified file: gene_id, count
awk '{print $4 "\t" $7}' "$OUTPUT_DIR/${sample}_gene_counts.txt" > "$TEMP_DIR/${sample}.simple.txt"

done < $OUTPUT_DIR/sample_list.txt
echo " Preprocessing completed."
# Step 2: Get all unique gene IDs
echo "Step 2: Collecting all gene IDs..."
awk '{print $1}' $OUTPUT_DIR/Tco-230_gene_counts.txt > $TEMP_DIR/all_genes.txt
total_genes=$(wc -l < $TEMP_DIR/all_genes.txt)
echo "Total genes: $total_genes"
# Step 3: Create header
echo "Step 3: Creating output file..."
echo -n "GeneID" > $OUTPUT_DIR/$FINAL_COUNTS_FILE
while read sample; do
echo -n ",$sample" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
done < $OUTPUT_DIR/sample_list.txt
echo "" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
# Step 4: Process in smaller batches to avoid memory issues
echo "Step 4: Merging counts (in batches of 1000 genes)..."
batch_size=1000
total_batches=$(( (total_genes + batch_size - 1) / batch_size ))
for ((batch=1; batch<=total_batches; batch++)); do
start_line=$(( (batch-1) * batch_size + 1 ))
end_line=$(( batch * batch_size ))
if [ $end_line -gt $total_genes ]; then
end_line=$total_genes
fi

echo "Processing batch $batch/$total_batches (genes $start_line-$end_line)..."

# Extract batch of genes
sed -n "${start_line},${end_line}p" $TEMP_DIR/all_genes.txt > $TEMP_DIR/batch_genes.txt

# Process this batch
while read gene_id; do
echo -n "$gene_id" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE

# Get count for each sample
while read sample; do
count_file="$TEMP_DIR/${sample}.simple.txt"
count=$(awk -v gene="$gene_id" '$1 == gene {print $2; exit}' "$count_file")
if [ -z "$count" ]; then
count="0"
fi
echo -n ",$count" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
done < $OUTPUT_DIR/sample_list.txt

echo "" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE

done < $TEMP_DIR/batch_genes.txt
done
# Cleanup
rm -rf $TEMP_DIR
echo "✅ Efficient merge completed: $OUTPUT_DIR/$FINAL_COUNTS_FILE"
echo "File size: $(ls -lh $OUTPUT_DIR/$FINAL_COUNTS_FILE | awk '{print $5}')"
# Show summary
echo ""
echo "First 3 lines:"
head -3 $OUTPUT_DIR/$FINAL_COUNTS_FILE | column -t -s,
EOF
chmod +x merge_gene_counts_efficient.sh
./merge_gene_counts_efficient.sh
ls -lh count_results/all_samples_gene_counts.csv
cd CIA/MyFirstPipeline/
git init
git log
git -log
git -log --oneline
history
history > my_Pipeline_script.sh
