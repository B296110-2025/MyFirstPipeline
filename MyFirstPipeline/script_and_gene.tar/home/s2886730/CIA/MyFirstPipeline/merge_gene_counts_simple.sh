#!/bin/bash
# filename: merge_gene_counts_simple.sh

OUTPUT_DIR="./count_results"
FINAL_COUNTS_FILE="all_samples_gene_counts.csv"

echo "Using simple merge method..."

# Get sample list
ls $OUTPUT_DIR/*_gene_counts.txt | sed 's/.*\///;s/_gene_counts.txt//' | sort > $OUTPUT_DIR/sample_list.txt

# Create header
echo -n "GeneID" > $OUTPUT_DIR/$FINAL_COUNTS_FILE
while read sample; do
    echo -n ",$sample" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
done < $OUTPUT_DIR/sample_list.txt
echo "" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE

# Use the first file as base and join others
base_file="$OUTPUT_DIR/Tco-230_gene_counts.txt"

echo "Merging files (this may take a few minutes)..."
awk -F'\t' -v output="$OUTPUT_DIR/$FINAL_COUNTS_FILE" -v sample_list="$OUTPUT_DIR/sample_list.txt" '
BEGIN {
    # Read sample list
    sample_count = 0
    while ((getline sample < sample_list) > 0) {
        samples[++sample_count] = sample
    }
    close(sample_list)
    
    # Initialize counts array
    for (i=1; i<=sample_count; i++) {
        sample_file = "count_results/" samples[i] "_gene_counts.txt"
        j = 0
        while ((getline line < sample_file) > 0) {
            split(line, fields, "\t")
            gene_id = fields[4]
            count = fields[7]
            counts[gene_id, i] = count
            j++
            if (j == 1) print "Processing " samples[i] ": " j " genes..." > "/dev/stderr"
        }
        close(sample_file)
        print "Completed " samples[i] ": " j " genes" > "/dev/stderr"
    }
}
{
    gene_id = $4
    printf "%s", gene_id >> output
    for (i=1; i<=sample_count; i++) {
        count = counts[gene_id, i]
        if (count == "") count = "0"
        printf ",%s", count >> output
    }
    printf "\n" >> output
}
' "$base_file"

echo "✅ Simple merge completed: $OUTPUT_DIR/$FINAL_COUNTS_FILE"
