#!/bin/bash
# filename: merge_gene_counts.sh

OUTPUT_DIR="./count_results"
FINAL_COUNTS_FILE="all_samples_gene_counts.csv"

echo "Starting to merge all sample gene counts..."

# Check if count files exist
if [ ! -f "$OUTPUT_DIR/Tco-230_gene_counts.txt" ]; then
    echo "Error: Gene count files not found. Please run generate_gene_counts.sh first."
    exit 1
fi

# Create merged count matrix
echo "Creating merged count matrix..."

# Get all sample names from count files
ls $OUTPUT_DIR/*_gene_counts.txt | sed 's/.*\///;s/_gene_counts.txt//' | sort > $OUTPUT_DIR/sample_list.txt

# Create header
echo -n "GeneID" > $OUTPUT_DIR/$FINAL_COUNTS_FILE
while read sample; do
    echo -n ",$sample" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
done < $OUTPUT_DIR/sample_list.txt
echo "" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE

# Extract gene IDs from first file (4th column is gene ID)
awk '{print $4}' $OUTPUT_DIR/Tco-230_gene_counts.txt > $OUTPUT_DIR/gene_ids.txt

# Count total genes and samples
total_genes=$(wc -l < $OUTPUT_DIR/gene_ids.txt)
total_samples=$(wc -l < $OUTPUT_DIR/sample_list.txt)

echo "Processing $total_genes genes across $total_samples samples..."

# Process each gene
counter=0
while read gene_id; do
    counter=$((counter + 1))
    if [ $((counter % 1000)) -eq 0 ]; then
        echo "Processed $counter genes..."
    fi
    
    echo -n "$gene_id" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
    
    # Get count for this gene from each sample
    while read sample; do
        count_file="$OUTPUT_DIR/${sample}_gene_counts.txt"
        # Extract count for this gene (7th column)
        count=$(awk -v gene="$gene_id" '$4 == gene {print $7}' "$count_file")
        if [ -z "$count" ]; then
            count="0"
        fi
        echo -n ",$count" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
    done < $OUTPUT_DIR/sample_list.txt
    
    echo "" >> $OUTPUT_DIR/$FINAL_COUNTS_FILE
    
done < $OUTPUT_DIR/gene_ids.txt

echo "✅ Merged counts file created: $OUTPUT_DIR/$FINAL_COUNTS_FILE"

# Show summary
echo ""
echo "Summary:"
echo "Total genes: $(wc -l < $OUTPUT_DIR/gene_ids.txt)"
echo "Total samples: $(wc -l < $OUTPUT_DIR/sample_list.txt)"
echo "File size: $(ls -lh $OUTPUT_DIR/$FINAL_COUNTS_FILE | awk '{print $5}')"

# Show first few lines
echo ""
echo "First 3 lines of merged file:"
head -3 $OUTPUT_DIR/$FINAL_COUNTS_FILE | column -t -s,
